CREATE TABLE Registrations (
    registration_id INT PRIMARY KEY,
    attendee_id INT,
    event_id INT,
    registration_date DATE,
    payment_status VARCHAR(50),
    FOREIGN KEY (attendee_id) REFERENCES Attendees(attendee_id),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);
-- Insert data into Registrations
INSERT INTO Registrations (registration_id, attendee_id, event_id, registration_date, payment_status) VALUES
(1, 1, 1, '2024-05-01', 'Paid'),
(2, 2, 2, '2024-06-15', 'Paid'),
(3, 3, 3, '2024-07-20', 'Pending'),
(4, 4, 4, '2024-08-10', 'Paid');

SELECT * FROM Registrations;

-- Query 1: Find registrations for a specific event
SELECT r.registration_id, r.registration_date, a.name AS attendee_name
FROM Registrations r
JOIN Attendees a ON r.attendee_id = a.attendee_id
WHERE r.event_id = (SELECT event_id FROM Events WHERE event_name = 'AI in Education Webinar');

-- Query 2: Count registrations by event
SELECT e.event_name, COUNT(r.registration_id) AS registration_count
FROM Registrations r
JOIN Events e ON r.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List distinct payment statuses
SELECT DISTINCT payment_status FROM Registrations;

-- Query 4: Find registrations with 'Paid' status
SELECT * FROM Registrations
WHERE payment_status = 'Paid';

-- Query 5: List registrations and their respective attendees
SELECT r.registration_id, a.name AS attendee_name, e.event_name
FROM Registrations r
JOIN Attendees a ON r.attendee_id = a.attendee_id
JOIN Events e ON r.event_id = e.event_id;