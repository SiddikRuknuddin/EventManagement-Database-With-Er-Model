-- 5. Schedules
CREATE TABLE Schedules (
    schedule_id INT PRIMARY KEY,
    event_id INT,
    session_name VARCHAR(255),
    start_time TIME,
    end_time TIME,
    location VARCHAR(255),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);
-- Insert data into Schedules
INSERT INTO Schedules (schedule_id, event_id, session_name, start_time, end_time, location) VALUES
(1, 1, 'Opening Keynote', '09:00:00', '10:00:00', 'Hall A'),
(2, 1, 'Tech Innovations Panel', '10:30:00', '12:00:00', 'Hall B'),
(3, 2, 'SEO Strategies', '09:00:00', '11:00:00', 'Room 101'),
(4, 3, 'Mental Health Awareness', '10:00:00', '11:30:00', 'Main Hall'),
(5, 4, 'AI Tools for Educators', '14:00:00', '15:30:00', 'Online');

SELECT * FROM Schedules;
-- Query 1: Find schedules for a specific event
SELECT session_name, start_time, end_time
FROM Schedules
WHERE event_id = (SELECT event_id FROM Events WHERE event_name = 'Health and Wellness Seminar');

-- Query 2: Count sessions by event
SELECT e.event_name, COUNT(s.schedule_id) AS session_count
FROM Schedules s
JOIN Events e ON s.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List distinct session names
SELECT DISTINCT session_name FROM Schedules;

-- Query 4: Find sessions starting in the morning (before 12 PM)
SELECT * FROM Schedules
WHERE start_time < '12:00:00';

-- Query 5: List schedules and their respective events
SELECT s.session_name, e.event_name
FROM Schedules s
JOIN Events e ON s.event_id = e.event_id;