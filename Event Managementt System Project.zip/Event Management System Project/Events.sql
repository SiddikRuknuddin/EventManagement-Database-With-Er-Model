-- 1. Events
CREATE TABLE Events (
    event_id INT PRIMARY KEY,
    event_name VARCHAR(255),
    event_type_id INT,
    date DATE,
    location VARCHAR(255),
    description TEXT,
    FOREIGN KEY (event_type_id) REFERENCES EventTypes(event_type_id)
);
-- Insert data into Events
INSERT INTO Events (event_id, event_name, event_type_id, date, location, description) VALUES
(1, 'Tech Innovators Conference', 1, '2024-06-15', 'Karachi Expo Center', 'A conference showcasing the latest in tech innovations.'),
(2, 'Digital Marketing Workshop', 2, '2024-07-10', 'Lahore University', 'A workshop to learn the latest digital marketing strategies.'),
(3, 'Health and Wellness Seminar', 3, '2024-08-20', 'Islamabad Convention Center', 'A seminar focusing on health and wellness topics.'),
(4, 'AI in Education Webinar', 4, '2024-09-05', 'Online', 'A webinar discussing the role of AI in education.');

SELECT * FROM Events;
-- Query 1: Find events happening in a specific location
SELECT * FROM Events
WHERE location = 'Karachi Expo Center';

-- Query 2: Count events by month
SELECT MONTH(date) AS event_month, COUNT(event_id) AS event_count
FROM Events
GROUP BY MONTH(date);

-- Query 3: List events with speakers
SELECT e.event_name, s.name AS speaker_name
FROM Events e
JOIN Speakers s ON e.event_id = s.event_id;
-- Query 4:
select event_name,sum(event_id) from Events
group by event_name;

-- Query 5: Get events with 'Conference' in their name
SELECT * FROM Events
WHERE event_name LIKE '%Conference%';

-- Query 6: List events and their types
SELECT e.event_name, et.event_type_name
FROM Events e
JOIN EventTypes et ON e.event_type_id = et.event_type_id;