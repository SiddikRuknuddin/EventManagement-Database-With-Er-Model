CREATE DATABASE Event_Managementt;
USE Event_Managementt;

-- 2. EventTypes
CREATE TABLE EventTypes (
    event_type_id INT PRIMARY KEY,
    event_type_name VARCHAR(255)
 );

-- 1. Events
CREATE TABLE Events (
    event_id INT PRIMARY KEY,
    event_name VARCHAR(255),
    event_type_id INT,
    date DATE,
    location VARCHAR(255),
    description TEXT,
    FOREIGN KEY (event_type_id) REFERENCES EventTypes(event_type_id)
);

-- 3. Attendees
CREATE TABLE Attendees (
    attendee_id INT PRIMARY KEY,
    event_id INT,
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(20),
    registration_date DATE,
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- 4. Speakers
CREATE TABLE Speakers (
    speaker_id INT PRIMARY KEY,
    event_id INT,
    name VARCHAR(255),
    bio TEXT,
    contact_info VARCHAR(255),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- 5. Schedules
CREATE TABLE Schedules (
    schedule_id INT PRIMARY KEY,
    event_id INT,
    session_name VARCHAR(255),
    start_time TIME,
    end_time TIME,
    location VARCHAR(255),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- 6. Venues
CREATE TABLE Venues (
    venue_id INT PRIMARY KEY,
    venue_name VARCHAR(255),
    address VARCHAR(255),
    capacity INT
);

-- 7. Registrations
CREATE TABLE Registrations (
    registration_id INT PRIMARY KEY,
    attendee_id INT,
    event_id INT,
    registration_date DATE,
    payment_status VARCHAR(50),
    FOREIGN KEY (attendee_id) REFERENCES Attendees(attendee_id),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- 8. Sponsors
CREATE TABLE Sponsors (
    sponsor_id INT PRIMARY KEY,
    event_id INT,
    sponsor_name VARCHAR(255),
    contact_info VARCHAR(255),
    sponsorship_level VARCHAR(50),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- 9. Tasks
CREATE TABLE Tasks (
    task_id INT PRIMARY KEY,
    event_id INT,
    task_description TEXT,
    assigned_to VARCHAR(255),
    deadline DATE,
    status VARCHAR(50),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- 10. Feedback
CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY,
    event_id INT,
    attendee_id INT,
    rating INT,
    comments TEXT,
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
    FOREIGN KEY (attendee_id) REFERENCES Attendees(attendee_id)
);


-- Insert data into EventTypes
INSERT INTO EventTypes (event_type_id, event_type_name) VALUES
(1, 'Conference'),
(2, 'Workshop'),
(3, 'Seminar'),
(4, 'Webinar');

-- Insert data into Events
INSERT INTO Events (event_id, event_name, event_type_id, date, location, description) VALUES
(1, 'Tech Innovators Conference', 1, '2024-06-15', 'Karachi Expo Center', 'A conference showcasing the latest in tech innovations.'),
(2, 'Digital Marketing Workshop', 2, '2024-07-10', 'Lahore University', 'A workshop to learn the latest digital marketing strategies.'),
(3, 'Health and Wellness Seminar', 3, '2024-08-20', 'Islamabad Convention Center', 'A seminar focusing on health and wellness topics.'),
(4, 'AI in Education Webinar', 4, '2024-09-05', 'Online', 'A webinar discussing the role of AI in education.');

-- Insert data into Attendees
INSERT INTO Attendees (attendee_id, event_id, name, email, phone, registration_date) VALUES
(1, 1, 'Ali Raza', 'ali.raza@example.com', '03001234567', '2024-05-01'),
(2, 2, 'Sara Khan', 'sara.khan@example.com', '03111234567', '2024-06-15'),
(3, 3, 'Zainab Ahmed', 'zainab.ahmed@example.com', '03221234567', '2024-07-20'),
(4, 4, 'Usman Tariq', 'usman.tariq@example.com', '03331234567', '2024-08-10');

-- Insert data into Speakers
INSERT INTO Speakers (speaker_id, event_id, name, bio, contact_info) VALUES
(1, 1, 'Dr. Faisal Rehman', 'Expert in AI and Machine Learning', 'faisal.rehman@example.com'),
(2, 2, 'Ayesha Ali', 'Digital Marketing Guru', 'ayesha.ali@example.com'),
(3, 3, 'Dr. Muhammad Siddiq', 'Wellness Coach and Nutritionist', 'muhammad.siddiq@example.com'),
(4, 4, 'Dr. Saira Shah', 'AI in Education Specialist', 'saira.shah@example.com');

-- Insert data into Schedules
INSERT INTO Schedules (schedule_id, event_id, session_name, start_time, end_time, location) VALUES
(1, 1, 'Opening Keynote', '09:00:00', '10:00:00', 'Hall A'),
(2, 1, 'Tech Innovations Panel', '10:30:00', '12:00:00', 'Hall B'),
(3, 2, 'SEO Strategies', '09:00:00', '11:00:00', 'Room 101'),
(4, 3, 'Mental Health Awareness', '10:00:00', '11:30:00', 'Main Hall'),
(5, 4, 'AI Tools for Educators', '14:00:00', '15:30:00', 'Online');

-- Insert data into Venues
INSERT INTO Venues (venue_id, venue_name, address, capacity) VALUES
(1, 'Karachi Expo Center', 'University Road, Karachi', 5000),
(2, 'Lahore University', 'Canal Road, Lahore', 2000),
(3, 'Islamabad Convention Center', 'Constitution Avenue, Islamabad', 3000);

-- Insert data into Registrations
INSERT INTO Registrations (registration_id, attendee_id, event_id, registration_date, payment_status) VALUES
(1, 1, 1, '2024-05-01', 'Paid'),
(2, 2, 2, '2024-06-15', 'Paid'),
(3, 3, 3, '2024-07-20', 'Pending'),
(4, 4, 4, '2024-08-10', 'Paid');

-- Insert data into Sponsors
INSERT INTO Sponsors (sponsor_id, event_id, sponsor_name, contact_info, sponsorship_level) VALUES
(1, 1, 'TechCorp', 'contact@techcorp.com', 'Gold'),
(2, 2, 'MarketMasters', 'info@marketmasters.com', 'Silver'),
(3, 3, 'HealthFirst', 'support@healthfirst.com', 'Platinum'),
(4, 4, 'EduTech', 'info@edutech.com', 'Bronze');

-- Insert data into Tasks
INSERT INTO Tasks (task_id, event_id, task_description, assigned_to, deadline, status) VALUES
(1, 1, 'Arrange catering services', 'Ali Raza', '2024-06-01', 'Completed'),
(2, 2, 'Set up workshop materials', 'Sara Khan', '2024-07-01', 'Pending'),
(3, 3, 'Organize guest speakers', 'Zainab Ahmed', '2024-08-01', 'In Progress'),
(4, 4, 'Test webinar platform', 'Usman Tariq', '2024-09-01', 'Not Started');

-- Insert data into Feedback
INSERT INTO Feedback (feedback_id, event_id, attendee_id, rating, comments) VALUES
(1, 1, 1, 5, 'Excellent event, very informative!'),
(2, 2, 2, 4, 'Great workshop, learned a lot.'),
(3, 3, 3, 3, 'Good seminar, but could have been better organized.'),
(4, 4, 4, 5, 'Fantastic webinar, very engaging and useful.');

-- Select statements to verify the data
SELECT * FROM EventTypes;
SELECT * FROM Events;
SELECT * FROM Attendees;
SELECT * FROM Speakers;
SELECT * FROM Schedules;
SELECT * FROM Venues;
SELECT * FROM Registrations;
SELECT * FROM Sponsors;
SELECT * FROM Tasks;
SELECT * FROM Feedback;


-- Query 1: Count events by type using JOIN
SELECT et.event_type_name, COUNT(e.event_id) AS event_count
FROM EventTypes et
LEFT JOIN Events e ON et.event_type_id = e.event_type_id
GROUP BY et.event_type_name;

-- Query 2: Find event types with no associated events using LEFT JOIN
SELECT et.event_type_name
FROM EventTypes et
LEFT JOIN Events e ON et.event_type_id = e.event_type_id
WHERE e.event_id IS NULL;

-- Query 3: Get distinct event type names
SELECT DISTINCT event_type_name FROM EventTypes;

-- Query 4: Find event types with a specific keyword in their name
SELECT * FROM EventTypes
WHERE event_type_name LIKE '%Web%';

-- Query 5: List event types where event_type_id is in a specific range using IN
SELECT * FROM EventTypes
WHERE event_type_id IN (1, 2, 3, 4);

-- Query 6: Using BETWEEN to find event types with event_type_id in a certain range
SELECT * FROM EventTypes
WHERE event_type_id BETWEEN 1 AND 5;

-- Query 1: Find events happening in a specific location
SELECT * FROM Events
WHERE location = 'Karachi Expo Center';

-- Query 2: Count events by month
SELECT MONTH(date) AS event_month, COUNT(event_id) AS event_count
FROM Events
GROUP BY MONTH(date);

-- Query 3: List events with speakers
SELECT e.event_name, s.name AS speaker_name
FROM Events e
JOIN Speakers s ON e.event_id = s.event_id;
-- Query 4:
select event_name,sum(event_id) from Events
group by event_name;

-- Query 5: Get events with 'Conference' in their name
SELECT * FROM Events
WHERE event_name LIKE '%Conference%';

-- Query 6: List events and their types
SELECT e.event_name, et.event_type_name
FROM Events e
JOIN EventTypes et ON e.event_type_id = et.event_type_id;

-- Query 1: Count attendees by event
SELECT e.event_name, COUNT(a.attendee_id) AS attendee_count
FROM Attendees a
JOIN Events e ON a.event_id = e.event_id
GROUP BY e.event_name;

-- Query 2: Find attendees for a specific event using subquery
SELECT name, email
FROM Attendees
WHERE event_id = (SELECT event_id FROM Events WHERE event_name = 'Tech Innovators Conference');

-- Query 3: List distinct attendee names
SELECT DISTINCT name FROM Attendees;

-- Query 4: List attendees and their respective events
SELECT a.name, e.event_name
FROM Attendees a
JOIN Events e ON a.event_id = e.event_id;

-- Query 5: Find registrations with payment status 'Paid' and specific registration date range using AND and BETWEEN
SELECT registration_id, registration_date, payment_status
FROM Registrations
WHERE payment_status = 'Paid' AND registration_date BETWEEN '2024-01-01' AND '2024-12-31';

-- Query 1: Find speakers for a specific event
SELECT s.name, s.bio
FROM Speakers s
JOIN Events e ON s.event_id = e.event_id
WHERE e.event_name = 'Digital Marketing Workshop';

-- Query 2: Count speakers by event
SELECT e.event_name, COUNT(s.speaker_id) AS speaker_count
FROM Speakers s
JOIN Events e ON s.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List distinct speaker names
SELECT DISTINCT name FROM Speakers;

-- Query 4: Find speakers with 'AI' in their bio
SELECT * FROM Speakers
WHERE bio LIKE '%AI%';

-- Query 5: List speakers and their respective events
SELECT s.name, e.event_name
FROM Speakers s
JOIN Events e ON s.event_id = e.event_id;

-- Query 1: Find schedules for a specific event
SELECT session_name, start_time, end_time
FROM Schedules
WHERE event_id = (SELECT event_id FROM Events WHERE event_name = 'Health and Wellness Seminar');

-- Query 2: Count sessions by event
SELECT e.event_name, COUNT(s.schedule_id) AS session_count
FROM Schedules s
JOIN Events e ON s.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List distinct session names
SELECT DISTINCT session_name FROM Schedules;

-- Query 4: Find sessions starting in the morning (before 12 PM)
SELECT * FROM Schedules
WHERE start_time < '12:00:00';

-- Query 5: List schedules and their respective events
SELECT s.session_name, e.event_name
FROM Schedules s
JOIN Events e ON s.event_id = e.event_id;

-- Query 1: Find events at a specific venue
SELECT e.event_name, v.venue_name
FROM Events e
JOIN Venues v ON e.location = v.venue_name
WHERE v.venue_name = 'Lahore University';

-- Query 2: Count events by venue
SELECT v.venue_name, COUNT(e.event_id) AS event_count
FROM Venues v
LEFT JOIN Events e ON v.venue_name = e.location
GROUP BY v.venue_name;

-- Query 4: Find venues with capacity greater than 2000
SELECT * FROM Venues
WHERE capacity > 2000;

-- Query 5: List venues and the number of events hosted
SELECT v.venue_name, COUNT(e.event_id) AS event_count
FROM Venues v
LEFT JOIN Events e ON v.venue_name = e.location
GROUP BY v.venue_name;

-- Query 1: Find registrations for a specific event
SELECT r.registration_id, r.registration_date, a.name AS attendee_name
FROM Registrations r
JOIN Attendees a ON r.attendee_id = a.attendee_id
WHERE r.event_id = (SELECT event_id FROM Events WHERE event_name = 'AI in Education Webinar');

-- Query 2: Count registrations by event
SELECT e.event_name, COUNT(r.registration_id) AS registration_count
FROM Registrations r
JOIN Events e ON r.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List distinct payment statuses
SELECT DISTINCT payment_status FROM Registrations;

-- Query 4: Find registrations with 'Paid' status
SELECT * FROM Registrations
WHERE payment_status = 'Paid';

-- Query 5: List registrations and their respective attendees
SELECT r.registration_id, a.name AS attendee_name, e.event_name
FROM Registrations r
JOIN Attendees a ON r.attendee_id = a.attendee_id
JOIN Events e ON r.event_id = e.event_id;

-- Query 1: Find sponsors for a specific event
SELECT s.sponsor_name, s.contact_info
FROM Sponsors s
JOIN Events e ON s.event_id = e.event_id
WHERE e.event_name = 'AI in Education Webinar';

-- Query 2: Count sponsors by event
SELECT e.event_name, COUNT(s.sponsor_id) AS sponsor_count
FROM Sponsors s
JOIN Events e ON s.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: Find sponsors with sponsorship level 'Gold' or 'Platinum' using IN
SELECT sponsor_name, contact_info, sponsorship_level
FROM Sponsors
WHERE sponsorship_level IN ('Gold', 'Platinum');

-- Query 4: List sponsors who provided contact information
SELECT sponsor_name, contact_info
FROM Sponsors
WHERE contact_info IS NOT NULL;

-- Query 5: Find sponsors for events held between two dates
SELECT s.sponsor_name, e.event_name, e.date
FROM Sponsors s
JOIN Events e ON s.event_id = e.event_id
WHERE e.date BETWEEN '2024-06-01' AND '2024-08-31';

-- Query 1: Find tasks for a specific event
SELECT t.task_description, t.assigned_to, t.deadline
FROM Tasks t
JOIN Events e ON t.event_id = e.event_id
WHERE e.event_name = 'Health and Wellness Seminar';

-- Query 2: Count tasks by event
SELECT e.event_name, COUNT(t.task_id) AS task_count
FROM Tasks t
JOIN Events e ON t.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List tasks assigned to a specific person using AND
SELECT task_description, assigned_to, status
FROM Tasks
WHERE assigned_to = 'Ali Raza' AND status = 'Completed';

-- Query 4: Find tasks with deadlines in the next month using BETWEEN
SELECT task_description, deadline, status
FROM Tasks
WHERE deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH);

-- Query 5: List distinct task statuses
SELECT DISTINCT status FROM Tasks;

-- Query 1: Find feedback for a specific event
SELECT f.rating, f.comments, a.name AS attendee_name
FROM Feedback f
JOIN Events e ON f.event_id = e.event_id
JOIN Attendees a ON f.attendee_id = a.attendee_id
WHERE e.event_name = 'Digital Marketing Workshop';

-- Query 2: Count feedback entries by event
SELECT e.event_name, COUNT(f.feedback_id) AS feedback_count
FROM Feedback f
JOIN Events e ON f.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: Find feedback with ratings  using HAVING
select rating, comments from FeedbaCK having rating >3;  

-- Query 4: Find feedback from specific attendees using IN
SELECT rating, comments
FROM Feedback
WHERE attendee_id IN (1, 2, 3);

-- Query 5: List distinct ratings
SELECT DISTINCT rating FROM Feedback;














