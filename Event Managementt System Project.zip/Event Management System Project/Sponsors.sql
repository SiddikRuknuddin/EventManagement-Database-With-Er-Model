-- 8. Sponsors
CREATE TABLE Sponsors (
    sponsor_id INT PRIMARY KEY,
    event_id INT,
    sponsor_name VARCHAR(255),
    contact_info VARCHAR(255),
    sponsorship_level VARCHAR(50),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);
-- Insert data into Sponsors
INSERT INTO Sponsors (sponsor_id, event_id, sponsor_name, contact_info, sponsorship_level) VALUES
(1, 1, 'TechCorp', 'contact@techcorp.com', 'Gold'),
(2, 2, 'MarketMasters', 'info@marketmasters.com', 'Silver'),
(3, 3, 'HealthFirst', 'support@healthfirst.com', 'Platinum'),
(4, 4, 'EduTech', 'info@edutech.com', 'Bronze');
SELECT * FROM Sponsors;
-- Query 1: Find sponsors for a specific event
SELECT s.sponsor_name, s.contact_info
FROM Sponsors s
JOIN Events e ON s.event_id = e.event_id
WHERE e.event_name = 'AI in Education Webinar';

-- Query 2: Count sponsors by event
SELECT e.event_name, COUNT(s.sponsor_id) AS sponsor_count
FROM Sponsors s
JOIN Events e ON s.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: Find sponsors with sponsorship level 'Gold' or 'Platinum' using IN
SELECT sponsor_name, contact_info, sponsorship_level
FROM Sponsors
WHERE sponsorship_level IN ('Gold', 'Platinum');

-- Query 4: List sponsors who provided contact information
SELECT sponsor_name, contact_info
FROM Sponsors
WHERE contact_info IS NOT NULL;

-- Query 5: Find sponsors for events held between two dates
SELECT s.sponsor_name, e.event_name, e.date
FROM Sponsors s
JOIN Events e ON s.event_id = e.event_id
WHERE e.date BETWEEN '2024-06-01' AND '2024-08-31';