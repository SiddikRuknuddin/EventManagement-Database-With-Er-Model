-- 3. Attendees
CREATE TABLE Attendees (
    attendee_id INT PRIMARY KEY,
    event_id INT,
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(20),
    registration_date DATE,
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);

-- Insert data into Attendees
INSERT INTO Attendees (attendee_id, event_id, name, email, phone, registration_date) VALUES
(1, 1, 'Ali Raza', 'ali.raza@example.com', '03001234567', '2024-05-01'),
(2, 2, 'Sara Khan', 'sara.khan@example.com', '03111234567', '2024-06-15'),
(3, 3, 'Zainab Ahmed', 'zainab.ahmed@example.com', '03221234567', '2024-07-20'),
(4, 4, 'Usman Tariq', 'usman.tariq@example.com', '03331234567', '2024-08-10');

SELECT * FROM Attendees;

-- Query 1: Count attendees by event
SELECT e.event_name, COUNT(a.attendee_id) AS attendee_count
FROM Attendees a
JOIN Events e ON a.event_id = e.event_id
GROUP BY e.event_name;

-- Query 2: Find attendees for a specific event using subquery
SELECT name, email
FROM Attendees
WHERE event_id = (SELECT event_id FROM Events WHERE event_name = 'Tech Innovators Conference');

-- Query 3: List distinct attendee names
SELECT DISTINCT name FROM Attendees;

-- Query 4: List attendees and their respective events
SELECT a.name, e.event_name
FROM Attendees a
JOIN Events e ON a.event_id = e.event_id;

-- Query 5: Find registrations with payment status 'Paid' and specific registration date range using AND and BETWEEN
SELECT registration_id, registration_date, payment_status
FROM Registrations
WHERE payment_status = 'Paid' AND registration_date BETWEEN '2024-01-01' AND '2024-12-31';