CREATE TABLE Tasks (
    task_id INT PRIMARY KEY,
    event_id INT,
    task_description TEXT,
    assigned_to VARCHAR(255),
    deadline DATE,
    status VARCHAR(50),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);
-- Insert data into Tasks
INSERT INTO Tasks (task_id, event_id, task_description, assigned_to, deadline, status) VALUES
(1, 1, 'Arrange catering services', 'Ali Raza', '2024-06-01', 'Completed'),
(2, 2, 'Set up workshop materials', 'Sara Khan', '2024-07-01', 'Pending'),
(3, 3, 'Organize guest speakers', 'Zainab Ahmed', '2024-08-01', 'In Progress'),
(4, 4, 'Test webinar platform', 'Usman Tariq', '2024-09-01', 'Not Started');

SELECT * FROM Tasks;

-- Query 1: Find tasks for a specific event
SELECT t.task_description, t.assigned_to, t.deadline
FROM Tasks t
JOIN Events e ON t.event_id = e.event_id
WHERE e.event_name = 'Health and Wellness Seminar';

-- Query 2: Count tasks by event
SELECT e.event_name, COUNT(t.task_id) AS task_count
FROM Tasks t
JOIN Events e ON t.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List tasks assigned to a specific person using AND
SELECT task_description, assigned_to, status
FROM Tasks
WHERE assigned_to = 'Ali Raza' AND status = 'Completed';

-- Query 4: Find tasks with deadlines in the next month using BETWEEN
SELECT task_description, deadline, status
FROM Tasks
WHERE deadline BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH);

-- Query 5: List distinct task statuses
SELECT DISTINCT status FROM Tasks;