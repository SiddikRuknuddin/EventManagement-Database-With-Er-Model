-- 4. Speakers
CREATE TABLE Speakers (
    speaker_id INT PRIMARY KEY,
    event_id INT,
    name VARCHAR(255),
    bio TEXT,
    contact_info VARCHAR(255),
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
);
-- Insert data into Speakers
INSERT INTO Speakers (speaker_id, event_id, name, bio, contact_info) VALUES
(1, 1, 'Dr. Faisal Rehman', 'Expert in AI and Machine Learning', 'faisal.rehman@example.com'),
(2, 2, 'Ayesha Ali', 'Digital Marketing Guru', 'ayesha.ali@example.com'),
(3, 3, 'Dr. Muhammad Siddiq', 'Wellness Coach and Nutritionist', 'muhammad.siddiq@example.com'),
(4, 4, 'Dr. Saira Shah', 'AI in Education Specialist', 'saira.shah@example.com');

SELECT * FROM Speakers;

-- Query 1: Find speakers for a specific event
SELECT s.name, s.bio
FROM Speakers s
JOIN Events e ON s.event_id = e.event_id
WHERE e.event_name = 'Digital Marketing Workshop';

-- Query 2: Count speakers by event
SELECT e.event_name, COUNT(s.speaker_id) AS speaker_count
FROM Speakers s
JOIN Events e ON s.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: List distinct speaker names
SELECT DISTINCT name FROM Speakers;

-- Query 4: Find speakers with 'AI' in their bio
SELECT * FROM Speakers
WHERE bio LIKE '%AI%';

-- Query 5: List speakers and their respective events
SELECT s.name, e.event_name
FROM Speakers s
JOIN Events e ON s.event_id = e.event_id;