-- 10. Feedback
CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY,
    event_id INT,
    attendee_id INT,
    rating INT,
    comments TEXT,
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
    FOREIGN KEY (attendee_id) REFERENCES Attendees(attendee_id)
);

-- Insert data into Feedback
INSERT INTO Feedback (feedback_id, event_id, attendee_id, rating, comments) VALUES
(1, 1, 1, 5, 'Excellent event, very informative!'),
(2, 2, 2, 4, 'Great workshop, learned a lot.'),
(3, 3, 3, 3, 'Good seminar, but could have been better organized.'),
(4, 4, 4, 5, 'Fantastic webinar, very engaging and useful.');
SELECT * FROM Feedback;
-- Query 1: Find feedback for a specific event
SELECT f.rating, f.comments, a.name AS attendee_name
FROM Feedback f
JOIN Events e ON f.event_id = e.event_id
JOIN Attendees a ON f.attendee_id = a.attendee_id
WHERE e.event_name = 'Digital Marketing Workshop';

-- Query 2: Count feedback entries by event
SELECT e.event_name, COUNT(f.feedback_id) AS feedback_count
FROM Feedback f
JOIN Events e ON f.event_id = e.event_id
GROUP BY e.event_name;

-- Query 3: Find feedback with ratings  using HAVING
select rating, comments from FeedbaCK having rating >3;  

-- Query 4: Find feedback from specific attendees using IN
SELECT rating, comments
FROM Feedback
WHERE attendee_id IN (1, 2, 3);

-- Query 5: List distinct ratings
SELECT DISTINCT rating FROM Feedback;