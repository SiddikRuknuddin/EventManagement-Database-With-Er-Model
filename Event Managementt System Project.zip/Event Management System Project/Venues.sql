-- 6. Venues
CREATE TABLE Venues (
    venue_id INT PRIMARY KEY,
    venue_name VARCHAR(255),
    address VARCHAR(255),
    capacity INT
);
-- Insert data into Venues
INSERT INTO Venues (venue_id, venue_name, address, capacity) VALUES
(1, 'Karachi Expo Center', 'University Road, Karachi', 5000),
(2, 'Lahore University', 'Canal Road, Lahore', 2000),
(3, 'Islamabad Convention Center', 'Constitution Avenue, Islamabad', 3000);
SELECT * FROM Venues;
-- Query 1: Find events at a specific venue
SELECT e.event_name, v.venue_name
FROM Events e
JOIN Venues v ON e.location = v.venue_name
WHERE v.venue_name = 'Lahore University';

-- Query 2: Count events by venue
SELECT v.venue_name, COUNT(e.event_id) AS event_count
FROM Venues v
LEFT JOIN Events e ON v.venue_name = e.location
GROUP BY v.venue_name;

-- Query 4: Find venues with capacity greater than 2000
SELECT * FROM Venues
WHERE capacity > 2000;

-- Query 5: List venues and the number of events hosted
SELECT v.venue_name, COUNT(e.event_id) AS event_count
FROM Venues v
LEFT JOIN Events e ON v.venue_name = e.location
GROUP BY v.venue_name;