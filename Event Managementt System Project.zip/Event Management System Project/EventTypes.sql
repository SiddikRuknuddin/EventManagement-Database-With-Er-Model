-- 2. EventTypes
CREATE TABLE EventTypes (
    event_type_id INT PRIMARY KEY,
    event_type_name VARCHAR(255)
 );
 -- Insert data into EventTypes
INSERT INTO EventTypes (event_type_id, event_type_name) VALUES
(1, 'Conference'),
(2, 'Workshop'),
(3, 'Seminar'),
(4, 'Webinar');

SELECT * FROM EventTypes;
-- Query 1: Count events by type using JOIN
SELECT et.event_type_name, COUNT(e.event_id) AS event_count
FROM EventTypes et
LEFT JOIN Events e ON et.event_type_id = e.event_type_id
GROUP BY et.event_type_name;

-- Query 2: Find event types with no associated events using LEFT JOIN
SELECT et.event_type_name
FROM EventTypes et
LEFT JOIN Events e ON et.event_type_id = e.event_type_id
WHERE e.event_id IS NULL;

-- Query 3: Get distinct event type names
SELECT DISTINCT event_type_name FROM EventTypes;

-- Query 4: Find event types with a specific keyword in their name
SELECT * FROM EventTypes
WHERE event_type_name LIKE '%Web%';

-- Query 5: List event types where event_type_id is in a specific range using IN
SELECT * FROM EventTypes
WHERE event_type_id IN (1, 2, 3, 4);

-- Query 6: Using BETWEEN to find event types with event_type_id in a certain range
SELECT * FROM EventTypes
WHERE event_type_id BETWEEN 1 AND 5;